'use strict';

var app=angular.module('app', ['ui.router']);
angular.module('app').config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $stateProvider.state('main', {
        url: '/main',
        templateUrl: 'views/main.html',
        controller: 'mainCtrl'
    }).state('login', {
        url: '/login',
        templateUrl: 'views/login.html',
        controller: 'loginCtrl'
    }).state('register', {
        url: '/register',
        templateUrl: 'views/register.html',
        controller: 'registerCtrl'
    }).state('mine', {
        url: '/mine',
        templateUrl: 'views/mine.html',
        controller: 'mineCtrl'
    }).state('category', {
        url: '/category',
        templateUrl: 'views/category.html',
        controller: 'categoryCtrl'
    }).state('cart', {
        url: '/cart',
        templateUrl: 'views/buycart.html',
        controller: 'buyCarCtrl'
    }).state('search', {
        url: '/search',
        templateUrl: 'views/search.html',
        controller: 'searchCtrl'
    }).state('searchlist', {
        url: '/searchlist',
        params:{"keyword":null},
        templateUrl: 'views/searchlist.html',
        controller: 'searchListCtrl'
    }).state('producer', {
        url: '/producer/:producerId',
        params:{"producerId":null,router:''},
        templateUrl: 'views/producerDetails.html',
        controller: 'producerDetailsCtrl'
    }).state('order', {
        url: '/order',
        templateUrl: 'views/myorder.html',
        controller: 'myorderCtrl'
    });

    $urlRouterProvider.otherwise('main');//其他
}]);

angular.module('app').controller('buyCarCtrl', ['$http', '$scope', "$timeout",'local','productInfo', function($http, $scope, $timeout,local,productInfo){


    $scope.totalCount=local.get("allCount");//商品总数显示State

    //获得购物车的全部商品
    $scope.productListArr=local.get("pro_infoArr");

    //默认全选

    $scope.isCheckAll=local.get("isCheckAll")?local.get("isCheckAll"):true;

    //是否选好的状态设置与全选同步

    $scope.isOk=angular.copy($scope.isCheckAll);//深拷贝

    //总价钱
    $scope.all_money=getTotalMoney();

    //全选和全不选的设置函数
    function checkAll(bool){
        for(var i in  $scope.productListArr){
            $scope.productListArr[i].isChecked=bool;
        }
    };

    //计算价格
    function getTotalMoney(){
        var n=0;//用于累计商品为isChecked的个数
        saveState();//放在获取allMoney之前
        var all_product=local.get("pro_infoArr")?local.get("pro_infoArr"):[];
        var totalMoney=0;
        for(var i in all_product){
           if(all_product[i].isChecked){
               n++;
               $scope.isOk=true;//有一个就是真的
               var count=all_product[i].count,
                   price=all_product[i].price;
                   totalMoney+=count*price;
           }else{
               $scope.isCheckAll=false;//一个没有就是假的
               local.put("isCheckAll",false);
               continue;
           }
        }
        console.log('n',n);
        if(n===all_product.length){
            $scope.isCheckAll=true;//全都选中为真
            local.put("isCheckAll",true);
        }else if(n===0){

            $scope.isOk=false;//一个都没有
            $scope.isCheckAll=false;//一个都没有
            local.put("isCheckAll",false);
        }
        return totalMoney.toFixed(1);
    };

    //check 操作
    $scope.check=function(i,item) {

        item.isChecked=!item.isChecked;

        $scope.all_money=getTotalMoney();
    };

    //checkAll 全选操作
    $scope.checkAll=function(i,item) {

        $scope.isCheckAll=!$scope.isCheckAll;

        checkAll($scope.isCheckAll);

        $scope.all_money=getTotalMoney();
    };
    //保存每一步操作的状态
    function saveState() {

        productInfo.save($scope.totalCount,$scope.productListArr);
    }
    /********************************addCart业务代码*******************************/
    $scope.addCart = function (obj) {

        obj.isChecked=true;

        productInfo.add(obj);

        $scope.totalCount=local.get("allCount");

        obj.count=getCount(obj);

        this.count=getCount(obj);

        $scope.isOk=true;

        $scope.all_money=getTotalMoney();
    };

    $scope.reduce= function (obj) {

        productInfo.reduce(obj);

        $scope.totalCount=local.get("allCount");

        obj.count=getCount(obj);

        this.count=getCount(obj);

        $scope.all_money=getTotalMoney();
    };
    //得某一个商品在购物车里的数量
    function getCount(obj){
        var id=obj.id;
        var proListArr=local.get("pro_infoArr");
        for(var k in proListArr){
            if(id===proListArr[k].id){
                return proListArr[k].count;
            }else {
                continue;
            }
        }
        return 0;
    }

    /********************************快递时间-代码*******************************/

    $scope.todayArr=["30分钟送达","15:00-16:00","16:00-17:00","17:00-18:00","18:00-19:00"]

    $scope.tomorrowArr=["09:00-10:00","10:00-11:00","11:00-12:00","12:00-13:00","13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00"]

    $scope.afterTommorrowArr=["09:00-10:00","10:00-11:00","11:00-12:00","12:00-13:00","13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00"]

    $scope.chooseTime=function () {

        $scope.time_show=!$scope.time_show
    }
    $scope.selectTime=function (text,item) {
        $scope.time_show=false;
        console.log(text,item);

        $scope.choose_time=text+item+'';

        console.log($scope.choose_time);
    }



}]);

angular.module('app').controller('categoryCtrl', ['$http', '$scope', "$timeout", 'local', 'productInfo','$location','$state', function ($http, $scope, $timeout, local, productInfo,$location,$state) {
    $http({
        method: 'GET',
        url: 'data/category.json'
    }).then(function successCallback(response) {

        $scope.categoryArr = response.data.data.categories;//左边分类模块

        $scope.product = response.data.data.products;//

        $scope.pro_listArr = $scope.product[103834];//右边商品列表数组

        $scope.CIDArr = $scope.categoryArr[0].cids;//分类项数组

        $scope.all_state = false;//分类列表

        $scope.soft_state = false;//排序列表

        $scope.index= 0;//分类模块索引

        $scope.totalCount=local.get("allCount");//商品总数显示

        $scope.showCategory = function (arrId, obj, index) { //arrId 分类数组id

            //console.log('左侧内容数组编号',arrId);

            $scope.index = index;//分类模块索引

            $scope.CIDArr = obj.cids; //分类选项数组

            $scope.pro_listArr = $scope.product[arrId];

        };
        //全部分类
        $scope.categoryAll=function(){

            $scope.soft_state = false;

            $scope.all_state = !$scope.all_state

        };
        //综合排序
        $scope.showSoft=function(){

            $scope.all_state = false;

            $scope.soft_state = !$scope.soft_state;

        };
        //过滤
        $scope.filterName = function(nameType) {

            if(nameType === '全部分类') {

                $scope.all_state = !$scope.all_state;

                return false;
            }
            $scope.name = nameType;

            $scope.all_state = !$scope.all_state
        };
        //排序
        $scope.orderType = function(type) {
            $scope.ordertype = type;
            $scope.soft_state = !$scope.soft_state
        };
        /********************************跳转到商品详情页业务代码*******************************/

        $scope.checkDetial=function(item){
            var router=$location.path().substring(1);

            var str = JSON.stringify(item);

            $state.go('producer', {"producerId": str,"router":router});
        };
        /********************************addCart业务代码*******************************/
        $scope.addCart = function (obj) {
            //this 的使用
            this.istrue = !this.istrue;

            productInfo.add(obj);

            $scope.totalCount=local.get("allCount");

            this.count=getCount(obj);
        };

        $scope.reduce= function (obj) {
            productInfo.reduce(obj);

            $scope.totalCount=local.get("allCount");

            this.count=getCount(obj);
        };
        //得某一个商品在购物车里的数量
        function getCount(obj){
            var id=obj.id;
            var proListArr=local.get("pro_infoArr");
            for(var k in proListArr){
                if(id===proListArr[k].id){
                    return proListArr[k].count;
                }else {
                    continue;
                }
            }
            return 0;
         }
    }, function errorCallback(response) {
        // 请求失败执行代码
    });

}]);
'use strict';
angular.module('app').controller('mainCtrl', ['$http', '$scope', "$timeout", 'local', 'productInfo','$state','$location', function ($http, $scope, $timeout, local, productInfo,$state,$location) {
    $http({
        method: 'GET',
        url: 'data/home.json'
    }).then(function successCallback(response) {

        /********************************页面数据初始化*******************************/

        $scope.roastArr = response.data.data.act_info[0]; //轮播图数组

        $scope.seckillArr = response.data.data.act_info[1]; //轮播图数组

        $scope.newProductArr = response.data.data.act_info[3]; //新品推荐数组

        $scope.conven_storeArr = response.data.data.act_info[4]; //便利店

        $scope.modulesArr = response.data.data.act_info[5]; //酒水饮料、休闲饮食、、、、、、

        /********************************轮播图初始化*******************************/
        $timeout(function () {
            $scope.mySwiper = new Swiper('.swiper-container', {
                loop: true,
                autoplay: 3000,
                //分页器
                pagination: '.swiper-pagination',
                autoplayDisableOnInteraction: false
            })
        }, 0);

        /********************************跳转到商品详情页业务代码 *******************************/

        $scope.lookDetial = function (obj) {

            var router=$location.path().substring(1);

            var str = JSON.stringify(obj);

            $state.go('producer', {"producerId": str,"router":router});
        };

        /********************************addCart业务代码**************************************/

        $scope.totalCount = local.get("allCount") ? local.get("allCount") : 0;//商品总数显示

        $scope.addCart = function (obj) {

            this.istrue = !this.istrue;

            productInfo.add(obj);

            $scope.totalCount = local.get("allCount");

        }
    }, function errorCallback(response) {
        // 请求失败执行代码
    });

}]);

angular.module('app').controller('mineCtrl', ['$http', '$scope', "$timeout",'local','productInfo', function($http, $scope, $timeout,local,productInfo){
    $scope.totalCount=local.get("allCount");//商品总数显示
    $scope.orderArr=['待付款','待收货','待评价','退款/售后'];
    $scope.other_server=['积分商城','优惠劵','收货地址','客服/反馈','关于我们'];
    $scope.toggleClass=function(){
    }

}]);

angular.module('app').controller('myorderCtrl', ['$http', '$scope', "$timeout",'local','productInfo', function($http, $scope, $timeout,local,productInfo){

    $scope.orderArr=['待付款','待收货','待评价','退款/售后'];
    $scope.index=0;
    $scope.toggleClass=function (index) {
        $scope.index=index;
    }

}])
'use strict';
angular.module('app').controller('producerDetailsCtrl', ['$http', '$scope', "$timeout",'local','productInfo','$state','$stateParams', function($http, $scope, $timeout,local,productInfo,$state,$stateParams){

    //获得页面传值
    $scope.productObj=JSON.parse($state.params.producerId);

    //显示商品总数
    $scope.totalCount=local.get("allCount");

    //页面跳转
    $scope.goto=function(){

        $state.go("cart");
    };
    //加入收藏
    $scope.addCollection=function (item) {
        local.put("collection",item);
    };
    /********************************addCart业务代码 start*******************************/

        $scope.addCart = function (obj) {
            //this 的使用 动画效果
            this.istrue = !this.istrue;
            //加入购物车
            productInfo.add(obj);
            //商品总数++
            $scope.totalCount=local.get("allCount");
            //该商品数++
            this.count=getCount(obj);
        };
        $scope.reduce= function (obj) {
            //加入购物车
            productInfo.reduce(obj);
            //商品总数--
            $scope.totalCount=local.get("allCount");
            //该商品数--
            this.count=getCount(obj);
        };
        //得某一个商品在购物车里的数量
        function getCount(obj){
            var id=obj.id;
            var proListArr=local.get("pro_infoArr");
            for(var k in proListArr){
                if(id===proListArr[k].id){
                    return proListArr[k].count;
                }else {
                    continue;
                }
            }
            return 0;
        }

    /********************************addCart业务代码 end*******************************/

}]);
'use strict';
angular.module('app').controller('searchCtrl', ['$http', '$scope', "$timeout",'local','productInfo','$location','$state',function($http, $scope, $timeout,local,productInfo,$location,$state){
    $scope.searchArr=["芒果",'水果',"火龙果","三七女王节","香烟","酒","燕塘","奇异果",'奶'];
    $scope.historyArr=[];
    $scope.historyState=false;
    $scope.search_text="";
    $scope.doSearch=function(key){
        if($scope.search_text!==undefined||key){
            $scope.historyState=true;
            if(key){
                $scope.historyArr.push(key);
                $state.go('searchlist', {"keyword": key});
            }else {
                $scope.historyArr.push($scope.search_text);
                $state.go('searchlist', {"keyword": $scope.search_text});
                $scope.search_text="";
            }
        }else {
            $scope.historyState=false;
            return false;
        }
    }
    $scope.clearHistory=function(){
        $scope.historyArr=[];

    }
}]);
'use strict';
angular.module('app').controller('searchListCtrl', ['$http', '$scope', "$timeout",'local','productInfo','$state','$stateParams', function($http, $scope, $timeout,local,productInfo,$state,$stateParams){
    $http({
        method: 'GET',
        url: 'data/goods.json'
    }).then(function successCallback(response) {

        $scope.listArr=response.data.data.goods;

        $scope.totalCount=local.get("allCount");//商品总数显示

        console.log($state);

        $scope.value="\'"+$stateParams.keyword+"\'";

        $scope.goto=function(){

          $state.go('cart');

        };
        /********************************addCart业务代码*******************************/
        $scope.addCart = function (obj) {
            //this 的使用
            this.istrue = !this.istrue;

            productInfo.add(obj);

            $scope.totalCount=local.get("allCount");

            this.count=getCount(obj);

        };

        $scope.reduce= function (obj) {
            productInfo.reduce(obj);

            $scope.totalCount=local.get("allCount");

            this.count=getCount(obj);
        };
        //得某一个商品在购物车里的数量
        function getCount(obj){
            var id=obj.id;
            var proListArr=local.get("pro_infoArr");
            for(var k in proListArr){
                if(id===proListArr[k].id){
                    return proListArr[k].count;
                }else {
                    continue;
                }
            }
            return 0;
        }
    }, function errorCallback(response) {
        // 请求失败执行代码
    });

}]);
app.directive('onFinishRenderFilters', function ($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
app.directive('footerBar', function($location,$timeout) {
    return {
        restrict : 'E',
        replace : true,
        scope : {
          totalCount:"=",
        },
        template :
        ' <div class="menu">'+
			'	<ul class="menu_list" >'+
					'<li ng-repeat="(i,item) in menuList"  on-finish-render-filters   ng-click="menuClick($index,item)">'+
						'<a href="" ur-sref="item.url">'+
							'<span class="icon"></span>'+
						   ' <span class="txt" ur-sref="category" >{{item.text}}</span>'+
						   ' <span ng-if="item.url==\'cart\'&&totalCount>0" class="shop_count">{{totalCount}}</span>'+
						'</a>'+
					'</li>'+
				'</ul>'+
		'	</div>',
        link : function(scope, element, attr) {

            var str=$location.path().substring(1);//字符串截取

            scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
                //下面是在dom render完成后执行的js
                if(str){
                    test(str);
                }
            });
            function test(str) {
                switch (true) {
                    case /main/.test(str):
                        element.children().find("li").eq(0).addClass("classLi1");
                        break;
                    case /category/.test(str):
                        element.children().find("li").eq(1).addClass("classLi2");
                        break;
                    case /cart/.test(str):
                        element.children().find("li").eq(2).addClass("classLi3");
                        break;
                    case /mine/.test(str):
                        element.children().find("li").eq(3).addClass("classLi4");
                        break;
                    default:
                        break;
                }
            };
            scope.menuList=[
                {
                    "text":"首页",
                    "className":"classLi1",
                    "url":'main'
                },
                {
                    "text":"闪送超市",
                    "className":"classLi2",
                    "url":'category'
                },
                {
                    "text":"购物车",
                    "className":"classLi3",
                    "url":'cart'
                },
                {
                    "text":"我的",
                    "className":"classLi4",
                    "url":'mine'
                },
            ]

            scope.menuClick=function(index,item){

                $location.path(item.url);
            };
        }
    }
});
//angular 自定义组件
'use strict';
app.directive("headerBar", function ($state) {
    return {
        restrict: "E",        // 指令是一个元素 (并非属性)
        scope: {              // 设置指令对于的scope
            //name: "@",          // name 值传递 （字符串，单向绑定）
            producerName: "=",        // amount 引用传递（双向绑定）
            //save: "&"           // 保存操作
        },
        template: function (el, attr) {
            var temp = '';
            if (angular.isDefined(attr.cartHeader)) {
                temp = "<header style='background:#f9fafd;border-bottom: none'>" +
                    '<h3><span >购物车</span></h3>' +
                    '</header>'
            } else if (angular.isDefined(attr.producerName)) {
                temp = "<header style='background:#f9fafd;'>" +
                    '<h3 class="producer"><span ng-click="backPage()" class="return"></span><span >{{producerName}}</span></h3>' +
                    '</header>'
            } else if (angular.isDefined(attr.order)) {
                temp = "<header style='background:#f9fafd;border-bottom:1px solid #e0e0e0'>" +
                    '<h3>' +
                    '<a href="javascript:void(0)" ui-sref="cart" class="return"></a>' +
                    '<span>我的订单</span>' +
                    '<a href="javascript:void(0)"  ui-sref="order"   class="refresh"></a>' +
                    '</h3>' +
                    '</header>'
            }
            else {
                temp = "<header>" +
                    '<h3><a href="javascript:void(0)" class="main_a">武汉街道口-B出口</a></h3>' +
                    '<a href=""  ui-sref="search"   class="icon_s"></a>' +
                    '</header>'
            }
            return temp;
        },
        replace: true,        // 使用模板替换原始标记
        link: function (scope, element, attr, controller) {

            scope.backPage = function () {

                var router = $state.params.router + '';

                $state.go(router);
            }
        }
    }
});  


//angular 自定义组件
app.directive("roastPitcure", function($timeout) {
    return {
        restrict: "E", // 指令是一个元素 (并非属性)
        scope: {
            roastArr: "="       // roastArr 引用传递（双向绑定）
        },
        template: // 替换HTML (使用scope中的变量)
        '<div class="carousel">' +
        '		<div class="banner">' +
        '		<div class="swiper-container">' +
        '			<div class="swiper-pagination"></div>' +
        '			<div class="swiper-wrapper">' +
        '				<div class="swiper-slide" ng-repeat="obj in roastArr.act_rows"  ><img  ng-src="{{obj.activity.img}}" /></div>' +
        '			</div>' +
        '		</div>' +
        '</div>',
        replace: true, // 使用模板替换原始标记
        link: function(scope, element, attrs, controller) {

            console.log('scope',scope);
        }
    }
});
'use strict';
angular.module('app').service('cache', ['$cookies', function($cookies){
    this.put = function(key, value){
      $cookies.put(key, value);
    };
    this.get = function(key) {
      return $cookies.get(key);
    };
    this.remove = function(key) {
      $cookies.remove(key);
    };
}]);

/**********相当于一个小型的数据库，用来存放用户的基本信息，购买商品的信息，需要两张表，用户信息表和商品列表，把这两种表关联在一起**************/
'use strict';
angular.module('app').service('local', ['$window', function($window){
    this.put = function(key, value){
        $window.localStorage.setItem(key, JSON.stringify(value));
    };
    this.get = function(key) {
        return JSON.parse($window.localStorage.getItem(key));
    };
    this.remove = function(key) {
        $window.localStorage.removeItem(key);
    };
    this.clear=function(){
        $window.localStorage.clear();
    }
}]);



'use strict';
angular.module('app').factory('productInfo', ['local', function(local){

      //local.clear();//清空数据

    var service = {};//定义一个Object对象'

    //私有函数用来判断当前商品是否以经添加过||返回商品的index
    function isNewPro(id,pro_infoArr){

        var pro_idArr=[];

        if(pro_infoArr.length==0){

            return {"state":true,"index":""}; //新产品

        }
        for(var k=0;k<pro_infoArr.length;k++){

            pro_idArr[k]=pro_infoArr[k].id;

        }

        if(pro_idArr.indexOf(id)===-1){

            return {"state":true,"index":""}; //新产品

        }else{
            return {"state":false,"index":pro_idArr.indexOf(id)}; //重复添加产品
        }
    };

    //添加数据
    service.add=function(proObj){

        var id=proObj.id,//获取当前商品的id

             pro_infoArr=local.get("pro_infoArr")?local.get("pro_infoArr"):[],//用来存放商品

             allCount=local.get("allCount")?local.get("allCount"):0,//用来存放商品总数量

             len=pro_infoArr.length,

             isTrue=isNewPro(id,pro_infoArr);// true-新加商品

        if(isTrue.state){     //新添加商品

            var proInfo={
                "id":proObj.id,
                "name":proObj.name,
                "img":proObj.img,
                "price":proObj.market_price,
                "count":1,
                "isChecked":true
            }

            pro_infoArr.push(proInfo);

            allCount++;

            local.put("allCount",allCount);//更新数据

            local.put("pro_infoArr",pro_infoArr);//更新数据


        }else{           //重复添加一个商品

            pro_infoArr[isTrue.index].count++;

            allCount++;

            local.put("allCount",allCount);//更新数据

            local.put("pro_infoArr",pro_infoArr);//更新数据


        }
    }

    service.reduce=function(proObj){

            var id=proObj.id,//获取当前商品的id

                pro_infoArr=local.get("pro_infoArr")?local.get("pro_infoArr"):[],//用来存放商品

                allCount=local.get("allCount")?local.get("allCount"):0,//用来存放商品总数量

                isTrue=isNewPro(id,pro_infoArr);// true-新加商品

            var count=pro_infoArr[isTrue.index].count;

            if(count===0){
                return false;
            }else{

                pro_infoArr[isTrue.index].count--;

                allCount--;

                local.put("allCount",allCount);//更新数据

                local.put("pro_infoArr",pro_infoArr);//更新数据
            }
         };

    service.save=function(allCount,pro_infoArr){

        local.put("allCount",allCount);//更新数据

        local.put("pro_infoArr",pro_infoArr);//更新数据

    }
         return service;
}]);
